#include<stdio.h>
struct node{
	int rollno;
	struct node *link;
};
struct node* head=NULL;
void addAtBegin(){
	struct node *a,*temp=head;
	a=(struct node*)malloc(sizeof(struct node));
	printf("Enter data to be inserted in the new node : ");
	scanf("%d",&a->data);
	while(temp!=NULL)
		if(temp->link!=head){
			temp=temp->link;
		}
	if(temp->link==head)
		temp->link=a;
	if(head==NULL){
		head=a;
		a->link=head;
	}
	else{
		a->link=head;
		head=a;
	}
}
void print(){
	struct node* temp;
	temp=head;
	while(temp->link!=head){
		printf("%d ",temp->data);
		temp=temp->link;
	}
	printf("%d\n",temp->data);
}
int countTheElements(){
	int n=0;
	struct node* temp=head;
	while(temp!=NULL && temp->link!=head){
		n++;
		temp=temp->link;
	}
	if(temp!=NULL && temp->link==head)
		n++;
	return 0;
}
void removeFirstElement(){
	struct node* temp;
	temp=head;
	if(countTheElements()==1 )
		head=NULL;
	else{
		while(temp->link!=head){
			temp=temp->link;
		}
		temp->link=head->link;
		head=head->link;
	}
}
void removeFromEnd(){
	struct node* temp1,temp2;
	temp1=head;
	temp2=head->link;
	while(temp2->link!=head){
		temp1=temp1->link;
		temp2=temp2->link;
	}
	temp1->link=head;
}
void addAtEnd(){
	struct node *temp=head,*a;
	a=(struct node*)malloc(sizeof(struct node));
	printf("Please enter data for the node to be inserted : ");
	scanf("%d",&a->data);
	while(temp->link!=head){
		temp=temp->link;
	}
	a->link=head;
	temp->link=a;
}
int main(){
	int r;
	head=NULL;
	printf("1.addAtBegin\n2.print\n3.countTheElements\n4.removeFirstElement\n5.addAtEnd\n6.removeFromEnd\n");
	while(1){
		printf("Enter one of the above operations : ");
label:
		scanf("%d",&r);
		switch(r){
			case 1 :addAtBegin();
				break;
			case 2 : print();
				 break;
			case 3 : printf("%d\n",countTheElements());
				 break;
			case 4 : removeFirstElement();
				 break;
			case 5 : addAtEnd();
				 break;
			case 6 : removeFromEnd();
				 break;
			case 7 : goto label2;
			default : printf("Please enter a valid operation :");
				  goto label;
		}
	}
label2:
	{;}
       return 0;
}

