#include<stdio.h>
#include<stdlib.h>
struct node{
                int data;
                struct node *link1,*link2;
};
struct node *head1,*head2,*swap;
	
void addAtBegin(struct node* head,int r){
	struct node *a;
	a=(struct node*)malloc(sizeof(struct node));
	printf("Enter data for the element to be inserted : ");
	scanf("%d",&a->data);
	a->link1=NULL;
	a->link2=head;
	if(head!=NULL)
		head->link1=a;
	head=a;
	if(r==1)
		head1=head;
	else head2=head;
	
}
void print(struct node* head){
	struct node* temp;
	temp=head;
	while(temp!=NULL){
		printf("%d ",temp->data);
		temp=temp->link2;
	}
		
}
void ithNodeOfTheList(struct node* head, int i){
	int j;
	struct node *temp;
	temp=head;
	for(j=1; j<i; ++j){
		if(temp!=NULL)
			temp=temp->link2;
	}
	printf("Data stored in the %dth node is : %d\n\n",i,temp->data);
}
//void mergeTwoLists(struct node *head1, struct node *head2){
		
//}
void sortTheList(struct node* head){
	struct node *temp1,*temp2;
	int swap;
	temp1=head;
	temp2=head->link2;
	while(temp1->link2!=NULL){
		while(temp2!=NULL){
			if(temp1->data>temp2->data){
				swap=temp1->data;
				temp1->data=temp2->data;
				temp2->data=swap;
			}
			temp2=temp2->link2;
		}
		temp1=temp1->link2;
		if(temp1!=NULL)
			temp2=temp1->link2;
	}
}
void mergeTwoSortedLists(struct node* head1,struct node* head2){
	struct node *temp1,*temp2,*temp;
	temp1=head1,temp2=head2;
	while(temp2!=NULL){
		if(temp2->data<=temp1->data){
			if(temp1==head1){
				temp=temp2->link2;
				temp2->link2=head1;
				temp1->link1=temp2;
				temp2->link1=NULL;
				head1=temp2;
				temp2=temp;
			}
			else{
				temp=temp2->link2;
				temp2->link2=temp1;
				temp2->link1=temp1->link1;
				(temp1->link1)->link2=temp2;
				temp1->link1=temp2;
				temp2=temp;
			}
		}
		else if(temp2->data>temp1->data){
			if(temp1->link2==NULL){
				temp=temp2->link2;
				temp2->link1=temp1;
				temp1->link2=temp2;
				temp1=temp2;
				temp2->link2=NULL;
				temp2=temp;
			}
			else{
				temp1=temp1->link2;
			}
		}
	}
	head2=NULL;
}
void printForwardRecursively(struct node *temp){
	if(temp!=NULL){
		printf("%d ",temp->data);
		printForwardRecursively(temp->link2);
	}	
}
void printBackwardRecursively(struct node* temp){
	if(temp!=NULL){
		printf("%d ",temp->data);
		printBackwardRecursively(temp->link1);
	}
}
void reverseListRecursively(struct node* temp,struct node* head){
	while(temp!=NULL){
		swap=temp->link1;
		temp->link1=temp->link2;
		temp->link2=swap;
		temp=temp->link1;
		if(temp!=NULL)
			reverseListRecursively(temp,swap,head);
	}
}
void rotateClockwise(struct node* head, int n){
	int i;
	struct node* temp=head;
	while(temp->link2!=NULL){
		temp=temp->link2;
	}
	temp->link2=head;
	head->link1=temp;
	for(i=1; i<=n; ++i){
		head=head->link2;
	}
	temp=head;
	head->link1=NULL
	while(temp->link2!=head)
		temp=temp->link2;
	temp->link2=NULL;
}
void createALoop(struct node* head,int n1,int n2){
	int i;
	for(i=)
}
int main(){
	int n,r,i;
	struct node *head,*temp,*swap;
	head1 = NULL;
	head2 = NULL;
	
//(a) Write a function to merge two lists.
//(b) Write a function to get/access the data at the ith node of the list.
//(c) Write a function to merge two sorted linked lists such that after merging theresultant list is also sorted.
//(d) Use recursion to print the list.
//(e) Use recursion to print the list in the reverse order.
//(f) Use recursion to reverse the list.
//(g) It may happen that in a (faulty) doubly linked list having some of the nodes
//pointing to some random node with their previous pointers. Write a function
//to rectify the list, if it is faulty.
//(h) Given a doubly-linked list and a positive integer n, write a function to rotate
//the linked list clockwise by n modulo l nodes, where l is the length of the list.
	printf("1.addAtBegin\n2.retrieve data at a particular position in the list\n3.sort the list\n4.merge lists so that the final list is also sorted\n5.print\n6.print recursively in forward direction\n7.print recursively in backward direction\n8.reverse list recursively\n9.exit\n");
	while(1){
		printf("Enter one of the following above operations : ");
label:
		scanf("%d",&n);
		switch(n){
			case 1 : printf("Enter list number : ");
				 scanf("%d",&r);
				 if(r==1)
					 head=head1;
				 else head=head2;
				 addAtBegin(head,r);
				 break;
			case 2 : printf("Enter list number as well as the node number : ");
                                 scanf("%d %d",&r,&i);
                                 if(r==1)
                                         head=head1;
                                 else head=head2;
				 ithNodeOfTheList(head,i);
				 break;
			case 3 : printf("Enter list number : ");
                                 scanf("%d",&r);
                                 if(r==1)
                                         head=head1;
                                 else head=head2;
				sortTheList(head);
				break;
			case 5 :  printf("Enter list number : ");
                                 scanf("%d",&r);
                                 if(r==1)
                                         head=head1;
                                 else head=head2;
				 print(head);
				 break;
			case 4 : mergeTwoSortedLists(head1,head2);
				 head2=NULL;
				 printf("Now list 1 contains list1 and list2 ,and list2 is empty \n");
				 break;
			case 6 : printf("Enter list number : ");
                                 scanf("%d",&r);
                                 if(r==1)
                                         head=head1;
                                 else head=head2;
				 temp=head;
				 printForwardRecursively(temp);
				 printf("\n");
				 break;
			case 7 : printf("Enter list number : ");
                                 scanf("%d",&r);
                                 if(r==1)
                                         head=head1;
                                 else head=head2;
				 temp=head;
				 while(temp->link2!=NULL)
					 temp=temp->link2;
				 printBackwardRecursively(temp);
				 printf("\n");
				 break;
			case 8 : printf("Enter list number : ");
                                 scanf("%d",&r);
                                 if(r==1)
                                         head=head1;
                                 else head=head2;
                                 temp=head;
				 reverseListRecursively(temp,head);
				 if(r==1)
					 head1=head;
				 else head2=head;
				 break;
			case 9 : goto label2;
			default: printf("Please enter a valid operation : ");
				 goto label; 

		}
	}
label2:{;}
	return 0;
}
