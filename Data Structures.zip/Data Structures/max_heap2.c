#include<stdio.h>
#include<stdlib.h>
int maxsize=10;
void shift_up(int *h,int in,int size){
	int par=(in-1)/2,i=in,temp;
	while( i>0 && h[parent]<h[i]){
		temp=h[par];
		h[par]=h[i];
		h[i]=temp;
		i=par;
		par=(i-1)/2;
	}
}
void shift_down(int *h,int in,int size){
	int l,r,maxindex,i=in,temp;
	while(1){
		maxindex=i;
		l=2*i+1;
		if(l<size && h[maxindex]<h[l])
			maxindex=l;
		r=2*i+2;
		if(r<size && h[maxindex]<h[r])
			maxindex=r;
		if(i != maxindex){
			temp=h[i];
			h[i]=h[maxindex];
			h[maxindex]=temp;
			i=maxindex;
		}
		else break;
	}
}
void insert(int *h,int n, int* size){
	*size = *size+1;
	if(*size > maxsize)
		h=(int*)realloc(h,sizeof(int)*(size+5));
	h[*size - 1]=n;
	if(size>1)
		shift_up(h, *size -1, *size);
}
int extract_max(int *h,int* size){
	int temp=h[0];
	h[0]=h[*size - 1];
	*size = *size -1;
	shift_down(h,0, *size);
	return temp;
}
void remove_element(int *h,int in,int *size){
	int maxpriority = h[0];
	h[in]=maxpriority+1;
	shift_up(h,in,*size);
	int temp=extract_max(h,size);
}
void change_priority(int *h,int p,int in,int size){
	int temp=h[in];
	h[in]=p;
	if(p>temp)
		shift_up(h,in,size);
	else if(p<temp)
		shift_down(h,in,size);
}
int main(){
	int *h,r,in,n,size=0;
	h=(int*)malloc(sizeof(int)*maxsize);
	printf("Enter one of the following operations on the max binary heap : \n");
	printf("1.insert an element\n2.extract max\n3.remove an element\n4.change priority of an element\n");
	while(1){
		printf("Enter the operation which you want to perform on the max binary heap : ");
label:
		scanf("%d",&r);
		switch(r){
			case 1 : prinf("Enter the element which you want to insert : ");
				 scanf("%d",&n);
				 insert(h,n,&size);
				 break;
			case 2 : n=extract_max(h,&size);
				 printf("%d\n",n);
				 break;
			case 3 : printf("Enter the index of the element to be removed : ");
				 scanf("%d",&in);
				 remove_element(h,in,&size);
				 break;
			case 4 : printf("Enter index of the element of the element and its new priority : ");
				 scanf("%d %d",&in,&n);
				 change_priority(h,n,in,size);
				 break;
			case 5 : goto label2;

			default : printf("Enter a valid operation : ");
				  goto label;
		}
	}
label2:
	{;}
	return 0;
}
