#include<stdio.h>
#include<stdlib.h>
struct node{
    int data,height;
    struct node *parent,*right,*left;
};
struct node* allocate(int n){
	struct node* a;
	a=(struct node*)malloc(sizeof(struct node));
	a->height = 0;
	a->data = n;
	a->left = NULL;
	a->right = NULL;
	return a;
}
void left_right(struct node **temp,struct node **a);

void left_left(struct node **temp,struct node **a);

void right_left(struct node **temp,struct node **a);

void right_right(struct node **temp,struct node **a);

void right_rotation(struct node **a,struct node **b);

void left_rotation(struct node **a, struct node **b);

void avl_tree_balancer(struct node **root,struct node **a){
	struct node *temp = ((*a)->parent)->parent,*temp2;
	int x,y,lh,rh;
	if(temp->left != NULL)
		x = (temp->left)->height;
	else x=-1;
	if(temp->right != NULL)
		y = (temp->right)->height;
	else y=-1;
	while(temp != NULL && (x-y < 2) && (x-y > -2)){
		temp=temp->parent;
		if(temp != NULL && temp->left != NULL)
			x = (temp->left)->height;
		else x = -1;
		if(temp != NULL && temp->right != NULL)
			y = (temp->right)->height;
		else y = -1;
	}
	//printf("hi\n");
	if(temp != NULL){
		if(temp->left != NULL)
			lh = (temp->left)->height;
		else lh = -1;
		if(temp->right != NULL)
                        rh = (temp->right)->height;
                else rh = -1;
		if( lh > rh){
			temp2=temp->left;
			if(temp2->left!=NULL)
                        	lh = (temp2->left)->height;
                	else lh = -1;
                	if(temp2->right!=NULL)
                        	rh = (temp2->right)->height;
                	else rh = -1;

			if( lh>rh){
				left_left(&temp,root);
			} 
			else{
				left_right(&temp,root);
			}
			//printf("hi\n");
		}
		else{
			temp2 = temp->right;
			if(temp2->left != NULL)
                                lh = (temp2->left)->height;
                        else lh = -1;
                        if(temp2->right != NULL)
                                rh = (temp2->right)->height;
                        else rh = -1;
			printf("hi\n");
			if( lh>rh){
				right_left(&temp,root);
			}
			else{
				right_right(&temp,root);
			}
		}
	}
//	printf("hi\n");
}
void insert_a_node(struct node **root,int n){
	int h1,h2,max,h,lh,rh,r;
	struct node *a,*temp,*temp1,*temp2;
    	a=allocate(n);
	if(*root == NULL){
        	*root = a;
        	a->parent=NULL;
    	}
    	else{
        	temp = *root;
        	while(1){
        		if(n<temp->data){
                		if(temp->left!=NULL){
	        			temp=temp->left;
                		}
                		else{
                    			temp->left=a;
	                    		a->parent=temp;
					if(temp->right && (temp->right)->height>=0)
						r=0;
					else 
						r=1;
        	            		break;
                		}
			}
        	    	else {
                		if(temp->right!=NULL){
                    			temp=temp->right;
	                	}
        	        	else{
                	    		temp->right=a;
                    			a->parent=temp;
					if(temp->left && (temp->left)->height>=0)
						r=0;
					else 
						r=1;

	                    		break;
        	        	}
            		}
        	}
	}
	
	if( ((*root) != a) && r){
		temp->height=1;
		temp=temp->parent;
 
		while(temp){
                	temp1=temp->left;
                	temp2=temp->right;
	                if(temp1){
        	                lh=temp1->height;
                	}
                	else lh=-1;
	                if(temp2)
        	                rh=temp2->height;
                	else rh=-1;
		        if(lh>rh)
        		        max=lh;
                	else max=rh;
			if(temp->height != max+1)
				temp->height=max+1;
			else 
				break;
                        temp=temp->parent;
		}	
		printf("hi1\n");
		if((*root)->height >= 2)
			avl_tree_balancer(root,&a);
//		printf("hi\n");
	}
}
void left_left(struct node **a, struct node **root){
	right_rotation(a,root);
}
void right_right(struct node **a, struct node **root){
	left_rotation(a,root);
}
void left_right(struct node **a,struct node **root){
	struct node *k2,*k1;
	k2=(*a)->left;
	k1=k2->right;
	left_rotation(&k2,root);
	right_rotation(a,root);
}
void right_left(struct node **a,struct node **root){
	struct node *k2,*k1;
	k2 = (*a)->right;
//	k1 = k2->left;
	printf("hi2\n");
	right_rotation(&k2,root);
	printf("hi3\n");
	left_rotation(a,root);
	printf("hi4\n");
}
void right_rotation(struct node **a,struct node **root){
	int h,ch,dh,ah,h1,h2;
	struct node *k2,*par,*C,*D,*A,*temp1,*temp2,*temp;
	D=(*a)->right;
	if(D!=NULL)
		dh = D->height;
	else dh = -1;
	char c;
	par= (*a)->parent;
	if(par!=NULL){
		if(par->right == (*a))
			c='r';
		else c='l';
	}
	k2 = (*a)->left;
	h = k2 -> height;
	C = k2->right;
	A = k2->left;
	if(A)
		ah = A->height;
	else ah = -1;
	if(C != NULL)
		ch = C->height;
	else ch = -1;
	if(C != NULL)
		C->parent=(*a);
	(*a)->left = C;
	k2->right=(*a);
	(*a)->parent=k2;
	
	if( ch > dh)            	      // height updation
		(*a)->height = ch+1;
	else (*a)->height = dh+1;
	
	if(ah > (*a)->height)
		k2->height = ah+1;
	else k2->height = (*a)->height + 1;

	if(par != NULL){
		if(c=='l')
			par->left=k2;
		else par->right=k2;
	}
	else *root = k2;
	k2->parent=par;
	while(par){
		temp1=par->left;
		temp2=par->right;
		if(temp1)
			h1=temp1->height;
		else h1=-1;
		if(temp2)
			h2=temp2->height;
		else h2=-1;
		if(h1>=h2)
			h=h1;
		else h=h2;
		if(par->height != h+1)
			par->height=h+1;
		par=par->parent;
	}
}
void left_rotation(struct node **a,struct node **root){
	int ah,bh,h,ch,p=1,h1,h2; 
	char c;
	struct node *k2,*par,*B,*A,*temp,*temp1,*temp2,*C;
	par=(*a)->parent;
	if(par != NULL){
		if(par->right == (*a))
			c='r';
		else c='l';
	}
	else p = 0;
	A = (*a)->left;
	if( A != NULL){
		ah = A->height;
	}
	else ah=-1;
	
	k2 = (*a)->right;
	C = k2->right;
	if(C)
		ch = C->height;
	else ch=-1;
        B = k2->left;	
	if( B != NULL){
		bh = B->height;
		B->parent = (*a);
	}
	else bh = -1;
	(*a)->right = B;
	k2->left=(*a);
	(*a)->parent = k2;
	k2->parent=par;
	if(bh > ah)
		(*a)->height = bh+1;
	else (*a)->height = ah+1;
  	if((*a)->height>ch)
		k2->height = (*a)->height + 1; 
	else k2->height = ch+1;
	if(par != NULL){
		if(c=='l')
			par -> left = k2 ;
		else par -> right = k2 ;
	}
	else *root = k2; 	
	 while(par != NULL){
                temp1=par->left;
                temp2=par->right;
                if(temp1!=NULL)
                        h1=temp1->height;
                else h1=-1;
                if(temp2!=NULL)
                        h2=temp2->height;
                else h2=-1;
                if(h1>=h2)
                        h=h1;
                else h=h2;
                if(par->height != h+1)
                	par->height=h+1;
                par=par->parent;
        }

}
void inorder_avl_tree(struct node *root){
	if(root->left != NULL)
		inorder_avl_tree(root->left);
	printf("%d ",root->data);
	if(root->right != NULL)
		inorder_avl_tree(root->right);
}
void preorder_avl_tree(struct node *root){
	printf("%d ",root->data);
	if(root->left != NULL)
		preorder_avl_tree(root->left);
	if(root->right != NULL)
		preorder_avl_tree(root->right);	
}
void print_heights_inorder(struct node *root){
	if(root->left != NULL)
		print_heights_inorder(root->left);
	printf("%d ",root->height);
	if(root->right != NULL)
		print_heights_inorder(root->right);	
}
struct node *find_node(struct node **root,int n){
	struct node *temp = *root;
	while(1){
		if(temp == NULL)
			return NULL;
		else if(n > temp->data){
			temp = temp->right;
		}
		else if(n < temp->data )
			temp = temp->left;
		else return temp;
	}
}
struct node *inorder_predecessor(struct node** root,int n){
	struct node *a = find_node(root,n);
	struct node *temp = a->left,*temp1;
	if(temp != NULL){
		while(temp->right != NULL)
			temp = temp->right;
		
		return temp;
	}
	else {
		temp1 = a;
		temp = a->parent;
		while(temp != NULL && temp->right != temp1){
			temp1 = temp;	
			temp = temp->parent;
		}
		if(temp->right == temp1)
			return temp;
		else 
			return NULL;
	}
}
struct node *inorder_successor(struct node **root, int n){
	struct node *a = find_node(root,n);
	struct node *temp = a->right, *temp1;
	if(temp != NULL){
		while(temp->left != NULL)
			temp = temp->left;
		
		return temp;
	}
	else {
		temp1 = a;
		temp = a->parent;
		while(temp != NULL && temp->left != temp1){
			temp1 = temp;
			temp = temp->parent;
		}
		if(temp->left == temp1)
			return temp;
		else return NULL;
	}
}
/*void delete_a_node(struct node **root, int n){
	struct node *a = find_node(root,n);
      	struct node *temp;
	temp =  
}*/
int main(){
    int r,n;
    struct node *root=NULL;
    printf("1.insert a node\n2.Inorder traversal\n3.preorder traversal\n4.print height inorder\n5.quit\n");
    while(1){
        printf("Enter one of the above operation : ");
        scanf("%d",&n);
        switch(n){
		case 1 : printf("Enter the data which you want to insert in the node : ");
			 scanf("%d",&r);
		         insert_a_node(&root,r);
			 break;
		case 2 : if(root != NULL){
			 	inorder_avl_tree(root);
				printf("\n");
			 }
			 else printf("The tree is empty\n");
			 break;
		case 3 : if(root != NULL)
				 preorder_avl_tree(root);
			 printf("\n");
			 break;
		case 4 : if(root != NULL) 
			 	print_heights_inorder(root);
			 printf("\n");
			 break;
		case 5 : goto label ;
		default : printf("This is not a valid operation valid operation\n");
        }
    }	
label:
    {;}
    return 0;
}
