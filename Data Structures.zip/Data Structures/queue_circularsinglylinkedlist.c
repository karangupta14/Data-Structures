#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *link;
};
//struct node *head1=NULL,*head2=NULL;
void enqueue(struct node *head1,struct node *head2){
	struct node *a=(struct node*)malloc(sizeof(struct node));
	printf("enter data for the node : ");
	scanf("%d",&a->data);
	if(head1==NULL){
		head1=a;
		head2=a;
		head1->link=a;
	}
	else{
		head2->link=a;
		a->link=head1;
		head2=head2->link;
	}
}
void dequeue(struct node *head1,struct node *head2){
	if(head1==NULL)
		printf("The queue is empty\n");
	else{
		if(head1==head2){
			head1=NULL;
			head2=NULL;
		}
		else{
			head1=head1->link;
			head2->link=head1;
		}
	}
}
void print(struct node *head1,struct node *head2){
	struct node *temp=head1;
	if(temp!=NULL){
		printf("Queue from front to back is : ");
		while(temp!=head2){
			printf("%d ",temp->data);
			temp=temp->link;
		}
		printf("%d\n",temp->data);
	}
}
int main(){
	int i;
	struct node *head1=NULL,*head2=NULL;
	printf("1.enqueue\n2.dequeue\n3.print\n4.exit\n");
	while(1){
		printf("Enter one of the following above operations : ");
label:
		scanf("%d",&i);
		switch(i){
			case 1 : enqueue(head1,head2);
				 break;
			case 2 : dequeue(head1,head2);
				 break;
			case 3 : print(head1,head2);
				 break;
			case 4 : goto label2;
			default : printf("Please enter a valid operation : ");
				goto label;  
		}
	}
label2:
	{;}
	return 0;
}
