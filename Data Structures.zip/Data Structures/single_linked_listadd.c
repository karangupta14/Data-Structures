//two_single_linked_lists
#include<stdio.h>
#include<stdlib.h>
struct node{
                int bin;
                int data;
                struct node* link;
};
struct node *head1,*head2;
void printTheElements(struct node *temp){
	if(temp!=NULL){
		printf("%d ",temp->data);
		temp=temp->link;
		printTheElements(temp);
	}
	
}
int countTheElements(struct node *head){
	struct node *temp;
	int n=0;
	temp=head;
	while(temp!=NULL){
		n++;
		temp=temp->link;
	}
	return n;
}
void addAtBegin(struct node* head){
	struct node *a;
	a->bin=0;
	a=(struct node*)malloc(sizeof(struct node));
	printf("please enter data for the node : ");
	scanf("%d",&a->data);
	a->link=head;
	head=a;
	
}
void sortTheList(struct node *head){
	struct node *temp1,*temp2;
	int n,i,j,swap;
	n=countTheElements(head);
	temp1=head;
	temp2=head->link;
	for(i=0; i<n-1; ++i){
		for(j=i+1; j<n; ++j){
			if(temp1->data>temp2->data){
				swap=temp1->data;
				temp1->data=temp2->data;
				temp2->data=swap;
			}
			if(temp2!=NULL)
				temp2=temp2->link;
		}	
		if(temp1->link!=NULL){
			temp1=temp1->link;
			temp2=temp1->link;
		}
	}
	
}
	
void removeFirstElement(struct node *head){
	head = head->link;
}
void addAtEnd(struct node *head){
	struct node* temp,*temp1;
	struct node *a;
	a->bin=0;
	a=(struct node*)malloc(sizeof(struct node));
	temp1=head;
	temp = head->link;
	printf("Enter data for the element to be inserted : ");
	scanf("%d",&a->data);
	while(1){    
		if(temp==NULL){
			temp1->link=a;
			a->link=NULL;
			goto label;
		}
		else {
			temp1=temp1->link;
			temp=temp->link;
		}
	}
	label:
	{;}
}
void removeFromEnd(struct node *head){
	struct node* temp,*temp1;
	temp1=head;
	temp=head->link;
	while(1){
                if(countTheElements(head)==1){
			head=NULL;
			goto label;
		}
		else if(temp->link==NULL){
			temp1->link=NULL;
			goto label;
		}
		else {
			temp=temp->link;
			temp1=temp1->link;
		}
	}
	label:
	{;}
}
void addAtAPosition(struct node *head){
	int n,i;
	struct node *a;
	a->bin=0;
	a=(struct node*)malloc(sizeof(struct node));
	struct node* temp,*temp1;
	temp=head;
	printf("Enter data for the element to be inserted : ");
	scanf("%d",&a->data);
	printf("Enter the position after which you want to insert a node : \n");
	scanf("%d",&n);
	for(i=1; i<n; ++i){
		temp=temp->link;
	}
	temp1=temp->link;
	temp->link=a;
	a->link=temp1;
}
void removeFromAPosition(struct node *head){
	struct node* temp,*temp1;
	temp1=head;
	temp=head->link;
	int n,i;
	printf("Enter the position from which you want to remove the node : ");
	scanf("%d",&n);
	if(n==1)
		head=head->link;
	else{
		for(i=1; i<n; ++i){
			temp=temp->link;
			temp1=temp1->link;
		}
		temp1->link=temp->link;	
	}
}
void reverseWithoutCreatingANewList(struct node *head){
	struct node *temp,*temp1,*temp2;
	temp=head;
	temp1=head;
	temp2=temp1->link;
	while(temp1->link != NULL){
		if(temp1==head){
			temp1->link = NULL;
			temp1=temp2;
			temp2=temp2->link;
		}
		else {
			temp1->link=temp;
			temp=temp1;
			temp1=temp2;
			temp2=temp2->link;
				
		}
	}
	temp1->link=temp;
	head=temp1;
}
void insertElementsInASortedList(struct node *head){
	int n=countTheElements(head),i;
	struct node *a,*temp1,*temp2;
	a=(struct node*)malloc(sizeof(struct node));
	a->bin =0;
	printf("Enter data for the element to be inserted in a sorted list : ");
	scanf("%d",&a->data);
	temp1=head;
	prev=head;
}
void mergeTwoLists(struct node *head1,struct node *head2){
	struct node *temp;
	temp=head1;
	while(temp->link!=NULL){
		temp=temp->link;
	}
	temp->link=head2;
	head2=NULL;
	printf("Now list 2 is enpty and list 1 is a merger of previous two lists\n");
}
void mergeTwoListsInOneSuchThatTheFinalListIsAlsoSortedList(struct node *head1,struct node *head2){
	struct node *temp1,*temp2,*temp3,*temp;
	temp1=head1,temp2=head2;
	while(temp2!=NULL){
		if(temp2->data <= temp1->data){
			if(temp1==head1){
				temp=temp2->link;
				temp2->link=temp1;
				head1=temp2;
				temp3=temp2;
				temp2=temp;
			}
			else {
				temp=temp2->link;
				temp2->link=temp1;
				temp3=temp2;
				temp2=temp;	
			}
		}
		else if(temp1->link==NULL){
			temp=temp2->link;
			temp1->link=temp2;
			temp2->link=NULL;
			temp3=temp1;
			temp1=temp1->link;
			temp2=temp;
		}
		else if(temp2->link>temp1->link){
			temp3=temp1;
			temp1=temp1->link;
		}
	}	
}
int ithNodeOfTheList(struct node *head,int i){
	struct node *temp;
	temp=head;
	int j;
	for(j=1; j<i; ++j)
		temp=temp->link;
	return temp->data;
}
int loopDetectorInAsortedList(struct node *head){
	int flag=0;
	struct node *sp,*fp;
	sp=head;
	fp=head;
	while(fp!=NULL && fp->link!=NULL){
		if(fp->link==sp){
			clearLoop(head);
			return 1;
		}
		else{
			sp=sp->link;
			fp=(fp->link)->link;
		}
	}
	return 0;
}
void clearLoop(struct node* head){
	int i;
	struct node *temp;
	temp=head;
	while(temp!=NULL){
		if(temp->bin!=0)
			temp->bin=1;
		if(temp->bin==1)
			temp->link=NULL;
	}
}
void reccursionToReverseTheList(struct node* temp1, struct node* temp2, struct node *prev){
	if(temp1==head){
		temp1->link=NULL;
		prev=temp1;
		temp1=temp2;
		if(temp2!=NULL)
			temp2=temp2->link;
	}
	else{
		temp1->link=prev;	
		prev=temp1;
		temp1=temp2;
		if(temp2!=NULL)
			temp2=temp2->link;
	}
	if(temp1!=NULL)
		reccursionToReverseTheList(temp1, temp2, prev);
}
void createALoop(struct node *head){
	int i,n;
	struct node *a,*temp=head,*pos;
	a=(struct node*)malloc(sizeof(struct node));
	printf("Enter the position of the element which you want to connect to the last node and enter data for the last element : ");
	scanf("%d %d",&n,&a->data);
	for(i=1; i<n; ++i)
		temp=temp->link;
	pos=temp;
	temp=head;
	while(temp->link!=NULL)	
		temp=temp->link;
	temp->link=pos;
	printf("The loop is created!!  Enjoy \n");
}	
int main(){
	struct node *head;
	struct node *temp1,*temp2,*prev;
	head1=NULL;
	head2=NULL;
	struct node *temp;
	int n;
	printf("1.addAtBegin\n2.printTheElementsUsingReccursion\n3.countTheElements\n4.sortTheList\n5.mergeTwoLists\n6.mergeTwoListsInOneSuchThatTheFinalListIsAlsoSortedList\n7.removeFirstElement\n8.addAtEnd\n9.removeFromEnd\n10.addAtaposition\n11.removeFromaPosition\n12.reverseElementsofList\n");
	printf("13.reverseWithoutCreatingANewList\n14.insertelementinasortedlist\n15.EXIT\n");
	while(1){
		int r;
		printf("Enter one of the following above operations and(if required) the list number on which you want to perform: ");
label2:
		scanf("%d",&n);
		switch(n){
			case 1 : scanf("%d",&r);
	  		         if(r==1)	
        	         	 head=head1;
			         else head=head2;
				 addAtBegin(head);
				 break;
			case 2 : printf("Enter which list you want to print :");
				 scanf("%d",&r);
				 struct node *temp;
				 if(r==1)
				 	temp=head1;
				 else temp=head2;
				 printTheElements(temp);
				 printf("\n");
				 break;
			case 3 : scanf("%d",&r);
        			 if(r==1)
        	        	 	head=head1;
			         else head=head2;
				 printf("%d\n",countTheElements(head));
				 break;
			case 4 : scanf("%d",&r);
      				 if(r==1)
		                 	head=head1;
			         else head=head2;
				 sortTheList(head);
				 break;
			case 5 : mergeTwoLists(head1,head2);
				 break;
			case 6 : scanf("%d",&r);
                                 if(r==1)
	                                 head=head1;
                                 else head=head2;
				 mergeTwoListsInOneSuchThatTheFinalListIsAlsoSortedList(head1,head2);
				 break;
                        case 7 : scanf("%d",&r);
                                 if(r==1)
        	                         head=head1;
                                 else head=head2;
				 removeFirstElement(head);
				 break;
			case 8 : scanf("%d",&r);
                                 if(r==1)
                	                 head=head1;
                                 else head=head2;
				 addAtEnd(head);
				 break;
		        case 9 : scanf("%d",&r);
                                 if(r==1)
                        	         head=head1;
                                 else head=head2;
				 removeFromEnd(head);
				 break;
			case 10 :scanf("%d",&r);
                                 if(r==1)
                                	 head=head1;
                                 else head=head2;
				  addAtAPosition(head);
				  break;
			case 11 : scanf("%d",&r);
                                  if(r==1)
	                                  head=head1;
                                  else head=head2;
				  removeFromAPosition(head);
				  break;
			case 12 : scanf("%d",&r);
                                  if(r==1)
        	                          head=head1;
                                  else head=head2; 
				  reverseElementsOfList(head);
				  break;
			case 13 : scanf("%d",&r);
                                  if(r==1)
                	                  head=head1;
                                  else head=head2;
				  reverseWithoutCreatingANewList(head);
				  break;
			case 14 : scanf("%d",&r);
                                  if(r==1)
                        	          head=head1;
                                  else head=head2;
				  insertElementInASortedList(head);
				  break;
			case 15 : scanf("%d",&r);
                                  if(r==1)
                                	  head=head1;
                                  else head=head2;
				  if(loopDetectorInAsortedList(head)==1)
					  printf("Yes! there is a loop\n");
				  else
					  printf("No, there is no loop\n");
				  break;
			case 16 : scanf("%d",&r);
				  if(r==1)
					  temp=head1;
				  else 
					  temp=head2;
				  temp1=head;
				  temp2=head->link;
				  prev=head;
				  reccursionToReverseTheList(temp1, temp2, prev);
				  head=prev;
				  if(r==1)
					  head1=prev;
				  else head2=prev;
				  break;
			case 17 : goto label;
			default : printf("Please enter a valid operation : ");
				  goto label2;
		}
	}
label:
	{;}
	return 0;
}
