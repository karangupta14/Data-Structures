#include<stdio.h>
#include<stdlib.h>
int i,j;
struct node{
	int data;
	struct node *parent,*left,*right;
};
void addNode(struct node** root, int n){
	struct node *a,*temp=*root;
	a=(struct node*)malloc(sizeof(struct node));
	a->data=n;
	if(*root==NULL){
		*root=a;
		a->right=NULL;
		a->left=NULL;
		a->parent=NULL;
	}
	else{
		while(1){
			if(a->data>temp->data){
				if(temp->right==NULL){
					temp->right=a;
					a->parent=temp;
					a->left=NULL;
					a->right=NULL;
					break;  //goto label3;
				}
				else{
					temp=temp->right;
				}
			}
			else if(a->data<temp->data){
				if(temp->left==NULL){
					temp->left=a;
					a->parent=temp;
					a->left=NULL;
					a->right=NULL;
					break; //goto label3;
				}
				else{
					temp=temp->left;
				}
			}
		}
		label3:
			{;}
	}
}
int findMin(struct node** root){
	struct node *temp;
	temp=*root;
	if(temp==NULL)
		printf("There is no element in the BST\n");
	else{
		while(temp->left!=NULL){
			temp=temp->left;	
		}
	//	printf("The minimum element of the bst is %d\n",temp->data);
		return temp->data;
	}
}
int findMax(struct node** root){
	struct node *temp;
	temp=*root;
	if(temp==NULL){
		printf("There is no element in the BST\n");
	}
	else{
		while(temp->right!=NULL){
			temp=temp->right;
		}
	//	printf("The max element of the bst is %d\n",temp->data);
		return temp->data;
	}
}
void inorder_traversal(struct node** root){
	struct node *temp=*root;
	if(temp->left != NULL){
		inorder_traversal(&(temp->left));
	}
	printf("%d ",temp->data);
	if(temp->right != NULL){
		inorder_traversal(&(temp->right));
	}
}
struct node* find_node(struct node** root,int n){
	struct node *temp;
	temp=*root;
	while(temp->data != n){
		if(temp->data>n){
			temp=temp->left;
		}
		else if(temp->data<n){
			temp=temp->right;
		}
	}
	return temp;
}
struct node* predecessor_of_node(struct node** root,int n){
	struct node* a,*temp1,*temp2;
	a=find_node(root,n);
	if(a->left!=NULL){
		temp1=a->left;
		while(1){
			if(temp1->right!=NULL){
				temp1=temp1->right;
			}
			else{
				//printf("%d\n",temp1->data);
				return temp1;
			}
		}
	}
	else if(a->parent!=NULL){
		temp1=a;
		temp2=a->parent;
		while(temp2->right!=temp1){
			if(temp2->parent != NULL){
				temp2=temp2->parent;
				temp1=temp1->parent;
			}
			else{
				//printf("predecessor of %d doesn't exist\n",n);
				return NULL;
			}
		}
		//printf("preecessor of %d is %d",n,temp2->data);
		return temp2;
	}
	else
		return NULL;
}
struct node* successor_of_node(struct node** root, int n){
	struct node *temp1,*temp2,*a;
	a=find_node(root,n);
	if(a->right!=NULL){
		temp1=a->right;
		while(temp1->left!=NULL){
			temp1=temp1->left;
		}
	//	printf("Successor of %d is : %d\n",n,temp1->data);
		return temp1;
	}
	else if(a->parent != NULL){
		temp1=a;
		temp2=a->parent;
		while(temp2->left!=temp1){
			if(temp2->parent!=NULL){
				temp1=temp1->parent;
				temp2=temp2->parent;
			}
			else{
				//printf("successor of %d doesn't exist\n",n);
				return NULL;
			}
			//printf("successor of %d is %d",n,temp2->data);
			return temp2;
		}
	}
	else return NULL;
}
void preorder_traversal(struct node** root){
	struct node *temp;
	temp=*root;
	printf("%d ",temp->data);
	if(temp->left != NULL){
		preorder_traversal(&(temp->left));
	}
	if(temp->right != NULL){
		preorder_traversal(&(temp->right));
	}
}
void postorder_traversal(struct node** root){
	struct node *temp;
	temp=*root;
	if(temp->left != NULL){
		postorder_traversal(&(temp->left));
	}
	if(temp->right != NULL){
		postorder_traversal(&(temp->right));
	}
	printf("%d ",temp->data);
}
int height_tree(struct node** root, int n){
	int n1=n,n2=n;
	struct node* temp;
	temp=*root;
	if(temp->left!=NULL){
		n1++;
		n1=height_tree(&(temp->left),n1);
	}
	if(temp->right!=NULL){
		n2++;
		n2=height_tree(&(temp->right),n2);
	}
	if(n1>n2)
		return n1;
	else return n2;
}
/*void levelorder_traversal(struct node** root){
	struct node *temp;
	temp=*root;
	
}*/
int height_node(struct node **root,int n){
	int h;
	struct node *a;
	a=find_node(root,n);
	h=height_tree(&a,0);
	return h;
}

void count_nodes(struct node** root){
	struct node *temp;
	temp=*root;
	if(temp->left != NULL || temp->right != NULL){
		i++;
		if(temp->left != NULL){
			count_nodes(&(temp->left));	
		}
		if(temp->right != NULL){
			count_nodes(&(temp->right));
		}	
	}
	else ++j;
//	return ;

}
void tree_using_inorder_preorder(struct node **root, int *in, int in1, int in2, int *pr, int pr1, int pr2){
	int r=pr[pr1],l=0,i=in1;
	addNode(root,pr[pr1]);
	while(i<=in2 && in[i]!=pr[pr1]){
		i++;
		l++;
	}
	if(l!=0){
		tree_using_inorder_preorder(root,in,in1,in1+l-1,pr,pr1+1,pr1+l);
	}
	if(in[in2]!=r){
		tree_using_inorder_preorder(root,in,in1+l+1,in2,pr,pr1+l+1,pr2);
	}
}
void tree_using_inorder_preorder(int *pr, int pr1, int pr2, int *in,int in1, int in2, struct node **temp){
        int i,d=pr[pr1],j;
        printf("%d\n",d);
        struct node *l,*r;
        l=(struct node*)malloc(sizeof(struct node));
        r=(struct node*)malloc(sizeof(struct node));
        j=in1,i=0;
        while(in[j] != d && j<=in2){
                i++;
                j++;
        }
        (*temp)->data=d;
        if(i!=0){
                l->parent = (*temp);
                (*temp)->left=l;
                tree_using_inorder_preorder(pr,pr1+1,pr1+i,in,in1,in1+i-1,&l);
        }
        else (*temp)->left=NULL;
        if(j!=in2){
                (*temp)->right=r;
                r->parent = (*temp);
                tree_using_inorder_preorder(pr,pr1+i+1,pr2,in,in1+i+1,in2,&r);
        }
        else (*temp)->right = NULL;
}

void clone_tree(struct node **root1, struct node **root2){
	struct node *temp1,*a;
	a=(struct node*)malloc(sizeof(struct node));
	temp1=*root1,*root2=a;
	a->data=temp1->data;
	if(temp1->left!=NULL){
		clone_tree(&(temp1->left),&(a->left));
	}
	if(temp1->right!=NULL){
		clone_tree(&(temp1->right),&(a->right));
	}
}
void mirror_tree(struct node **root1,struct node **root2){
	struct node *temp,*a;
	a=(struct node*)malloc(sizeof(struct node));
	temp=*root1,*root2=a;
	a->data=temp->data;
	if(temp->left!=NULL){
		mirror_tree(&(temp->left),&(a->right));
	}
	if(temp->right!=NULL){
		mirror_tree(&(temp->left),&(a->left));	
	}
}
void delete_a_node(struct node **root, int n,int r){
	struct node *a,*temp,*par,*l,*ri;
	a=find_node(root,n);
	par=a->parent;
	l=a->left;
	ri=a->right;
	if(a->left!=NULL || a->right!=NULL){
		if(r==0)
			temp=successor_of_node(root,n);
		else temp=predecessor_of_node(root,n);
		delete_a_node(root,temp->data,r);
		if(par->left==a){
			par->left=temp;	
		}
		else{
			par->right=temp;       
		}
		if(l!=NULL){
			l->parent=temp;
		}
		if(ri!=NULL){
			ri->parent=temp;
		}
		temp->left=l;
		temp->right=ri;
		temp->parent=par;
	}
	else{
		if(par->left==a)
			par->left=NULL;
		else
			par->right=NULL;
	}
}
int main(){
	int m,t,*pr,*in;
	struct node *root=NULL,*root2=NULL,**roota,*temp;
	printf("1.addnode\n2.inordertraversal\n3.preordertraversal\n4.postordertraversal\n5.findmin\n6.find max\n7.heightofbst\n8.successor\n9.predecessor\n10.Find height of a node\n ");
	printf("11.find number of leaf nodes\n12.construct new tree with inorder and preorder traversal(this will delete the old tree)\n13.clone tree\n14.delete a node\n15.exit\n");
	int n,r,r1;
	while(1){
		printf("Please enter one of the above operations and the tree number on which you want to perform the operation\n");
		printf("1 for bst \n2 for clone bst(only if generated before)\n");
label:
		scanf("%d",&n);
		if(n!=13){
			scanf("%d",&t);
			if(t==1) roota=&root;
			else if(t==2) roota=&root2;
		}
		switch(n){
			case 1 : printf("Please enter data for the node to be inserted  : ");
			         scanf("%d",&r);	
				 addNode(roota,r);
				 break;
			case 2 : inorder_traversal(roota);
				 printf("\n");
				 break;
			case 3 : preorder_traversal(roota);
				 printf("\n");
				 break;
			case 4 : postorder_traversal(roota);
				 printf("\n");
				 break;
			case 5 : printf("%d\n",findMin(roota));
				 break;
			case 6 : printf("%d\n",findMax(roota));
				 break;
			case 7 : printf("%d\n",height_tree(roota,0));
				 break;
			case 8 : printf("Please enter element of bst whose successor you want to know : ");
				 scanf("%d",&r);
				 temp=successor_of_node(roota,r);
				 if(temp!=NULL)
					 printf("%d\n",temp->data);
				 else printf("successor doesn't exist\n");
				 break;
			case 9 : printf("Please enter element of bst whose predecessor you want to know : ");
                                 scanf("%d",&r);
                                 temp=predecessor_of_node(roota,r);
				 if(temp!=NULL)
				 	printf("%d\n",temp->data);
				 else printf("predecessor doesn't exist\n");
                                 break;
			case 10 : printf("Enter the node which you want the height of : "); 
				  scanf("%d",&r);
				  printf("%d\n",height_node(roota,r));
				  break; 
			case 11 : i=0,j=0;
				  count_nodes(roota);
				  printf("number of leafy,nonleafy and total number of nodes are : %d %d %d\n",j,i,i+j);
				  break;
			case 12 : printf("Enter the length of inorder/preorder traversal : ");
				  scanf("%d",&r);
				  pr=(int*)malloc(sizeof(int)*r);
				  in=(int*)malloc(sizeof(int)*r);
				  printf("Enter the inorder traversal of the bst : ");
				  for(i=0 ; i<r; ++i)
				  	scanf("%d",&in[i]);
				  printf("Enter the preorder traversal of the bst : ");
				  for(i=0; i<r; ++i)
					scanf("%d",&pr[i]);
				  tree_using_inorder_preorder(roota,in,0,r-1,pr,0,r-1);
				  break;
			case 13 : clone_tree(&root,&root2);
				  break;
			case 14 : printf("Enter the number which you want to delete from the tree : ");	
				  scanf("%d",&r);
				printf("If you want to replace the internal deleted node with a successor enter 0, enter 1 for predecessor:");
				  scanf("%d",&r1);  
				delete_a_node(roota,r,r1);
				  break;	 	  
			case 15 : goto label2;
			default : printf("Please enter a valid operation and a tree number(not if 13): ");
				 goto label;
		}
	}	
label2:
	{;}
	return 0;
}
