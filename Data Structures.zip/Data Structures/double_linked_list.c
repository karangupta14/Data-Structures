#include<stdio.h>
#include<stdlib.h>
struct node{
	int rollno;
	struct node *link1,*link2;
};
struct node* head;
void addAtBegin(){
	struct node* a;
	a=(struct node*)malloc(sizeof(struct node));
	printf("Enter data of the element to be inserted : ");
	scanf("%d",&a->rollno);
	a->link1=NULL;
	a->link2=head;
	if(head!=NULL){
		head->link1=a;
	}
	head=a;
}
void printTheElements(){
	struct node* temp;
	temp=head;
	printf("Elements of the list printed in forward traversal are : \n");
	while(temp->link2!=NULL){
		printf("%d ",temp->rollno);
		temp=temp->link2;
	}
	printf("%d",temp->rollno);
	printf("\n");
	printf("Elements of the list printed in backward traversal are : \n");
	while(temp!=head){
		printf("%d ",temp->rollno);
		temp=temp->link1;
	}
	printf("%d",temp->rollno);
	printf("\n");
}
int countTheElements(){
	int n,i,count=0;
	struct node* temp;
	temp=head;
	while(temp!=NULL){
		count++;
		temp=temp->link2;
	}
	return count;
}
void removeFirstElement(){
	if(head!=NULL){
		head=head->link2;
		head->link1=NULL;
	}
	else printf("The list is empty");
}
void addAtEnd(){
	struct node* temp,*a;
	a=(struct node*)malloc(sizeof(struct node));
	printf("Enter the rollno of the element to be inserted in the end : ");
	scanf("%d",&(a->rollno));
	temp=head;
	if(temp!=NULL){
		while(temp->link2!=NULL){
			temp=temp->link2;
		}
		temp->link2=a;
		a->link1=NULL;
	}
	else {
		temp=a;
		temp->link1=NULL;
		temp->link2=NULL;
	}
}
void removeLastElement(){
	struct node *temp1,*temp2;
	temp1=head;
	if(temp1==NULL){
		printf("The list is empty\n");
		goto label4;
	}
	temp2=head->link2;
	while(temp2->link2!=NULL){
		temp1=temp1->link2;
		temp2=temp2->link2;
	}
	temp1->link2=NULL;
label4:
	{;}

}
void addAtAGivenPosition(){
	struct node* a,*temp1,*temp2;
	a=(struct node*)malloc(sizeof(struct node));
	int n,i;
	printf("Enter the position at which you want to insert an element : ");
	scanf("%d",&n);
	printf("Enter data(an integer) for the element : ");
	scanf("%d",&(a->rollno));	
	if(n==1){
		a->link2=head;
		head->link1=a;
		a->link1=NULL;
		head=a;
		goto label3;
	}
	temp1=head;
	temp2=head->link2;
	for(i=2; i<n; ++i){
		temp1=temp1->link2;
		temp2=temp2->link2;
	}
	temp2->link1=a;
	a->link2=temp2;
	a->link1=temp1;
	temp1->link2=a;
label3:
	{;}
}
void removeElementFromAGivenPosition(){
	struct node* temp1,*temp2,*temp3;
	int n,i;
	printf("Enter the position from which you want to remove the element");
	scanf("%d",&n);
	temp1=head;
	temp2=head;
	temp3=head->link2;
	
	for(i=1; i<n; ++i){
		if(i!=1){
			temp1=temp1->link2;
		}	
		temp3=temp3->link2;
	}
	if(n!=1){
		temp1->link2=temp3;
		temp3->link1=temp1;
	}
	else{
		head=temp3;
		temp3->link1=NULL;
	}
}
void addAfterOccuranceOfAGivenKeyValue(){
	struct node* a,*temp1,*temp2;
	a=(struct node*)malloc(sizeof(struct node));
	int n;
	printf("Enter key value : ");
	scanf("%d",&n);
	printf("Enter data of the node to be inerted : ");
	scanf("%d",&(a->rollno));
	temp1=head;
	temp2=head->link2;
	while(temp1->rollno!=n){
		temp1=temp1->link2;
		temp2=temp2->link2;
	}
	temp1->link2=a;
	temp2->link1=a;
	a->link1=temp1;
	a->link2=temp2;
}
void removeFirstOccuranceOfAGivenData(){
	struct node *temp1,*temp2;
	int n;
	printf("Enter key value : ");
	scanf("%d",&n);
	temp1=head;
	temp2=head;
	while(temp2->rollno!=n){
		if(temp2!=head){
			temp1=temp1->link2;
			temp2=temp2->link2;
		}
		else{
			temp2=temp2->link2;
		}
	}
	if(temp2==head){
		head=head->link2;
	}
	else if(temp2->link2!=NULL){
		temp2=temp2->link2;
		temp1->link2=temp2;
		temp2->link1=temp1;
	}
	else{
		temp1->link2=NULL;
	}
}
void reverseElementsWithoutCreatingANewList(){
	struct node *temp,*swap;
	temp=head;
	while(temp->link2!=NULL){
		swap=temp->link2;
		temp->link2=temp->link1;
		temp->link1=swap;
		temp=temp->link1;
	}
	swap=temp->link2;
	temp->link2=temp->link1;
	temp->link1=swap;

	head=temp;
}
void sortTheList(){   //Selection Sort
	struct node *temp1,*temp2,*temp;
	temp=head;
	int swap,i,j,n=countTheElements();
	temp1=head;
	temp2=head->link2;
	for(i=0; i<n-1; ++i){
		for(j=i+1; j<n; ++j){
			if(temp1->rollno>temp2->rollno){
				swap=temp1->rollno;
				temp1->rollno=temp2->rollno;
				temp2->rollno=swap;
			}
			if(temp2->link2!=NULL)
				temp2=temp2->link2;
		}
			temp1=temp1->link2;
			temp2=temp1->link2;
	}
}
	
void insertElementInASortedList(){
	struct node *a,*temp1,*temp2;
	a=(struct node*)malloc(sizeof(struct node));
	printf("Insert data od the element to be inserted");
	scanf("%d",&a->rollno);
	temp2=head;
	while(temp2->link2!=NULL && temp2->rollno < a->rollno){
		temp2=temp2->link2;
	}
	if(temp2==head){
		a->link2=head;
		head->link1=a;
		head=a;
	}
	else {
		temp1=temp2->link1;
		temp1->link2=a;
		temp2->link1=a;
		a->link1=temp1;
		a->link2=temp2;	
	}
}
int main(){ 
//(a) Write a function to add an element at the beginning of the list.
//(b) Write a function to print the elements in the list both with forward and back-
//ward traversals.
//(c) Write a function to count the number of elements in the list.
//(d) Write a function to remove the first element of the list.
//(e) Write a function to add an element at the end of the list.
//(f) Write a function to remove the last element of the list.
//(g) Write a function to add an element at a given position of the list.
//(h) Write a function to remove the element at a given position of the list.
//(i) Write a function to add data after the first occurrence of a given key value in
//the linked list.
//(j) Write a function to remove the first occurrence of a given data of the list.
//(k) Write a function to reverse the elements in the list.
//(l) Write a function to reverse the elements in the list without creating a new list.
//(m) Write a function to insert an element in a sorted list such that the final list is
//also sorted. 
//(n) Write a function to sort the elements in a list.

	head=NULL;
	int n;
	printf("1.addAtBegin\n2.printWithforwardAndBackwardReversal\n3.countElements\n4.removeFirstElement\n5.addAtEnd\n6.removeLastElement\n7.addAtAPosition\n8.removeElementFromAGivenPosition\n9.addAfterOccuranceOfAGivenKeyValue\n10.removeFirstOccuranceOfAGivenData\n11.reverseElementsOFTheList\n12.reverseElementsWithoutCreatingANewList\n13.sortTheList\n14.insertElementInASortedList\n15.exit\n");	
	while(1){
		  	printf("Enter one of the following above operations : ");
label:
			scanf("%d",&n);

		switch(n){
			case 1 : addAtBegin();
				 break;
			case 2 : printTheElements();
				 break;
			case 3 : printf("%d\n",countTheElements());
				 break;
			case 4 : removeFirstElement();
				 break;
			case 5 : addAtEnd();
        			 break;
			case 6 : removeLastElement();
				 break;
			case 7 : addAtAGivenPosition();
       				 break;
			case 8 : removeElementFromAGivenPosition();
				 break;
			case 9 : addAfterOccuranceOfAGivenKeyValue();
				 break;
			case 10 : removeFirstOccuranceOfAGivenData();
				 break;
			//case 11 : reverseElementsOfTheList();
			//	 break;
			case 12 : reverseElementsWithoutCreatingANewList();
				 break;
			case 13 : sortTheList();
				 break;
			case 14 : insertElementInASortedList();
				 break; 
			case 15 : goto label2;

			default : printf("Enter a valid operation number : ");
				  goto label;
		}	
	}
label2:
	{;}

}
