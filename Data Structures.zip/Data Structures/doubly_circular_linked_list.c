#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *link1,*link2;
};
struct node *head=NULL;
void addAtBegin(){
	struct node *temp,*a;
	a=(struct node*)malloc(sizeof(struct node));
	printf("Enter data for the element : ");
	scanf("%d",&a->data);
	if(head!=NULL){
		while(temp->link2!=head)
			temp=temp->link2;
		temp->link2=a;
		head->link1=a;
		a->link1=temp;
		a->link2=head;
		head=a;
	}	
	else{
		a->link2=a;
		a->link1=a;
		head=a;
	}
}
void print(){
	struct node* temp;
	temp=head;
	while(temp->link2!=head){
		printf("%d ",temp->data);
		temp=temp->link2;
	}
	printf("%d\n",temp->data);
}
int count(){
	int n=0;
	struct node *temp;
	temp=head;
	if(temp!=NULL){
		while(temp->link2!=head){
			n++;
			temp=temp->link2;
		}
	
	
		if(temp->link2==head)
			n++;
	}
	return n;

}
void removeFirstElement(){
	struct node* temp;
	temp=head;
	while(temp->link2!=head)
		temp=temp->link2;
	temp->link2=head->link2;
	head=head->link2;
	head->link1=temp;
}
void removeFromEnd(){
	struct node *temp;
	if(head->link2==head){
		head=NULL;
	}
	else{
		while((temp->link2)->link2!=NULL)
			temp=temp->link2;
		temp->link2=head;
		head->link1=temp;
	}
}
void insertAtEnd(){
	struct node *a,*temp=head;
	a=(struct node*)malloc(sizeof(struct node));
	printf("please enter data for the node : ");
	scanf("%d",&a->data);
	while(temp->link2!=head){
		temp=temp->link2;
	}
	temp->link2=a;
	head->link1=a;
	a->link2=head;
	a->link1=temp;
} 
int main(){
	int r;
	printf("1.add at begin\n2.print\n3.count\n4.remove from starting\n5.remove from end\n6.insert at end\n7.exit\n");
	while(1){
		printf("Please enter one of the following above operations : ");	
label:
		scanf("%d",&r);
		switch(r){
			case 1 : addAtBegin();
				 break;
			case 2 : print();
				 break;
			case 3 : printf("%d\n",count());
				 break;
			case 4 : removeFirstElement();
				 break;
			case 5 : removeFromEnd();
				 break;
			case 6 : insertAtEnd();
				 break;
			case 7 : goto label2;
			default : printf("Please enter a valid operation : ");
				  goto label;
		}
	}
label2:
	{;}
	return 0;
}
