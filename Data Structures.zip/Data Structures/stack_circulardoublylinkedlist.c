#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *link1,*link2;
};
void push(){
	struct node *a;
	a=(struct node*)malloc(sizeof(struct node));
	printf("Enter data for the element to be inserted : ");
	scanf("%d",&a->data);
	if(head1==NULL){
		head1=a;
		head2=a;
		a->link1=a;
		a->link2=a;
	}
	else{
		head2->link2=a;
		a->link1=head2;
		a->link2=head1;
		head2=head2->link2;
		head1->link1=a;
	}
}
void print(){
	struct node *temp;
	temp=head2;
	while(temp!=head1){
		printf("%d\n",temp->data);
		temp=temp->link1;
	}
	printf("%d\n",temp->data);
}
void pop(){
	if(head1->link2!=head1){
		head2=head2->link1;
		head2->link2=head1;
		head1->link1=head2;
	}
	else{
		head1=NULL;
		head2=NULL;
	}
}
int main(){
	struct node *head1=NULL,*head2=NULL,**head;
	int i;
	printf("1.push\n2.pop\n3.print\n4.exit\n");
	while(1){
		printf("Enter one of the above mentioned operations : ");
label:
		scanf("%d",&i);
		switch(i){
			case 1 : push();
				break;
			case 2 : pop();
				 break;
			case 3 : print();
				break;
			case 4 : goto label2;
			default :printf("Enter a valid operation number : "); 
				 goto label;
		}
	}
label2:
	{;}
	return 0;
}
